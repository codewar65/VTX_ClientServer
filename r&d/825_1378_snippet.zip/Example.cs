using System;
using System.Threading;
using System.IO;
using System.IO.Ports;

namespace YOUR_NAMESPACE_HERE
{
    public static class Program
    {
        public static void Main()
        {

            SerialPort comPort = new SerialPort("COM23", 115200, Parity.None, 8, StopBits.One);

            XMODEM_FullDotNET modem = new XMODEM_FullDotNET(comPort, XMODEM_FullDotNET.Variants.XModem1K);


            // ********** DEMONSTRATES FILE SENDING **********
            Console.Clear();
            Console.WriteLine("XMODEM file transfers are RECEIVER-DRIVEN.");
            Console.WriteLine("FIRST: Press <ENTER> to initiate data send.");
            Console.WriteLine("NEXT: Have receiver begin receiving data.");
            Console.ReadLine();
            Console.WriteLine("Sending data....");

            byte[] dataToSend = File.ReadAllBytes(@"C:\Users\MyUserName\Desktop\FileToSend.txt");
            int numBytesSent = modem.Send(dataToSend);
            // NOTE: AddToOutboundPacket() can be used to send data packet-by-packet (for example, to update a progress bar after each packet)
            // instead of all at once as demonstrated here.


            // ********** DEMONSTRATES FILE RECEIVING *********
            Console.Clear();
            Console.WriteLine("XMODEM file transfers are RECEIVER-DRIVEN.");
            Console.WriteLine("FIRST: Instruct sender to begin sending data.");
            Console.WriteLine("NEXT: Press <ENTER> to receive data.");
            Console.ReadLine();
            Console.WriteLine("Receiving data....");

            MemoryStream receivedMemoryStream = new MemoryStream();
            XMODEM_FullDotNET.TerminationReasonEnum terminationReason = modem.Receive(receivedMemoryStream);

            if (terminationReason == XMODEM_FullDotNET.TerminationReasonEnum.EndOfFile)
            {
                Console.WriteLine("FILE-RECEIVE COMPLETE!");            
                byte[] dataReceived = receivedMemoryStream.ToArray();

                // Strip any padding bytes they have been added to the end of the file, to ensure that the received
                // data is identical to the original
                dataReceived = modem.TrimPaddingBytesFromEnd(dataReceived);

                // Write received data to a file so it can be compared to the original
                FileStream receivedFile = new FileStream(@"C:\Users\MyUserName\Desktop\FileReceived.txt", FileMode.CreateNew);
                receivedFile.Write(dataReceived, 0, dataReceived.Length);
                receivedFile.Close();
            }
            else
            {
                Console.WriteLine("FILE-RECEIVE FAILED!");
            }


        } // End method

    } // End class
    
} // End namespace